package ac222qf2;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class Philosopher implements Runnable {
	
	private int id;
	
	private final ChopStick leftChopStick;
	private final ChopStick rightChopStick;

	private Random randomGenerator = new Random();
	 AtomicBoolean arePhilosphersDone = new AtomicBoolean(false);
	private int numberOfEatingTurns = 0;
	private int numberOfThinkingTurns = 0;
	private int numberOfHungryTurns = 0;
	
	private boolean isHungry;
	
  // private DeadLockCheck dl = new DeadLockCheck();

	private double thinkingTime = 0;
	private double eatingTime = 0;
	private double hungryTime = 0;
	
	
	public Philosopher(int id, ChopStick leftChopStick, ChopStick rightChopStick, int seed) {
		this.id = id;
		this.leftChopStick = leftChopStick;
		this.rightChopStick = rightChopStick;
		
		
		
		/*
		 * set the seed for this philosopher. To differentiate the seed from the other philosophers, we add the philosopher id to the seed.
		 * the seed makes sure that the random numbers are the same every time the application is executed
		 * the random number is not the same between multiple calls within the same program execution 
		 */
	
		randomGenerator.setSeed(id+seed);
		
		
	
	}
	public int getId() {
		return id;
	}

	public double getAverageThinkingTime() {
		//just divides the total time with the loops and finds the average
		return thinkingTime / numberOfThinkingTurns;
	}

	public double getAverageEatingTime() {
	
		return eatingTime / numberOfEatingTurns;
	}

	public double getAverageHungryTime() {
		
		return hungryTime / numberOfHungryTurns;
	}
	
	public int getNumberOfThinkingTurns() {
		return numberOfThinkingTurns;
	}
	
	public int getNumberOfEatingTurns() {
		return numberOfEatingTurns;
	}
	
	public int getNumberOfHungryTurns() {
		return numberOfHungryTurns;
	}

	public double getTotalThinkingTime() {
		return thinkingTime;
	}

	public double getTotalEatingTime() {
		return eatingTime;
	}

	public double getTotalHungryTime() {
		return hungryTime;
	}
	
	
	
   public boolean think(){
	try {
		System.out.println("Philosopher "+id+" is thinking.");
		int thinkslp = randomGenerator.nextInt(1000)  ;
		Thread.sleep(thinkslp);
		
		numberOfThinkingTurns ++;
		
		thinkingTime += thinkslp;
		
		
		
	} catch (InterruptedException e) {
		
	}
	return true;
	}
   
   
   
   
     public boolean hungry(){
    	 
		long start = System.currentTimeMillis();
			System.out.println("Philosopher "+id+" is hungry.");
	
		
			boolean pass = false;
			
		
			while(!pass){
					if(!leftChopStick.isItLocked()){
				
						leftChopStick.Lock();
						
						
						
						if(!rightChopStick.isItLocked()){
				
							 
					rightChopStick.Lock();
					System.out.println("Philosopher "+id+" picked up the right chopstick "+rightChopStick.getId()); 
					System.out.println("Philosopher "+id+" picked up the left chopstick "+leftChopStick.getId());		 
							 pass = true;
							 continue;
						 }
						else
						{
							 leftChopStick.UnLock();
						
					}
				}
				
				

				 
				   if(arePhilosphersDone.get())
					   return true;	
	          
	          
	         	     

			}		
			 
		long end = System.currentTimeMillis();
		
		long time = end - start;

		numberOfHungryTurns ++;
		hungryTime = hungryTime + time;
		 return eat();
	
		}
     
   
        public boolean eat(){
		try {
			System.out.println("Philosopher "+id+" is eating.");
			int eatslp = randomGenerator.nextInt(1000) ;
			
			Thread.sleep(eatslp);
			
			leftChopStick.UnLock();
			rightChopStick.UnLock();
			System.out.println("Philosopher "+id+" released the left chopstick "+leftChopStick.getId());	
			System.out.println("Philosopher "+id+" released the right chopstick "+rightChopStick.getId());	
			numberOfEatingTurns ++;
			eatingTime += eatslp;
			
		
			
		} catch (InterruptedException e) {
			
		}
		return true;
		}
   

	@Override
	public void run() {
		
		
		while(!arePhilosphersDone.get()){
			think();
			hungry();
			
		
		}
		
		
	}
}